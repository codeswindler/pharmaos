import { useState, useMemo } from "react";
import { useLocation } from "wouter";
import { useListProducts, useCreateTransaction, useListCustomers } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Search, Plus, Minus, Trash2, CreditCard, Banknote, Smartphone, User, ShoppingCart } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface CartItem {
  product: any;
  quantity: number;
}

export default function Checkout() {
  const [search, setSearch] = useState("");
  const [cart, setCart] = useState<CartItem[]>([]);
  const [paymentMethod, setPaymentMethod] = useState<"cash" | "card" | "mobile_money" | "other">("cash");
  const [paidAmount, setPaidAmount] = useState<string>("");
  const [customerName, setCustomerName] = useState("");
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const { data: products, isLoading: loadingProducts } = useListProducts({ search });
  const createTransaction = useCreateTransaction();

  const handleAddToCart = (product: any) => {
    if (product.stockQty <= 0) {
      toast({ title: "Out of stock", variant: "destructive" });
      return;
    }
    setCart((prev) => {
      const existing = prev.find((item) => item.product.id === product.id);
      if (existing) {
        if (existing.quantity >= product.stockQty) {
          toast({ title: "Cannot exceed available stock", variant: "destructive" });
          return prev;
        }
        return prev.map((item) =>
          item.product.id === product.id ? { ...item, quantity: item.quantity + 1 } : item
        );
      }
      return [...prev, { product, quantity: 1 }];
    });
  };

  const handleRemoveFromCart = (productId: number) => {
    setCart((prev) => prev.filter((item) => item.product.id !== productId));
  };

  const handleUpdateQuantity = (productId: number, delta: number) => {
    setCart((prev) =>
      prev.map((item) => {
        if (item.product.id === productId) {
          const newQty = item.quantity + delta;
          if (newQty <= 0) return item;
          if (newQty > item.product.stockQty) {
            toast({ title: "Cannot exceed available stock", variant: "destructive" });
            return item;
          }
          return { ...item, quantity: newQty };
        }
        return item;
      })
    );
  };

  const totals = useMemo(() => {
    const subtotal = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
    return { subtotal, total: subtotal };
  }, [cart]);

  const changeDue = useMemo(() => {
    const paid = parseFloat(paidAmount) || 0;
    return Math.max(0, paid - totals.total);
  }, [paidAmount, totals.total]);

  const handleProcessPayment = () => {
    if (cart.length === 0) return;
    
    const paid = parseFloat(paidAmount) || 0;
    if (paid < totals.total && paymentMethod === "cash") {
      toast({ title: "Paid amount is less than total", variant: "destructive" });
      return;
    }

    createTransaction.mutate(
      {
        data: {
          items: cart.map((item) => ({ productId: item.product.id, quantity: item.quantity })),
          paymentMethod,
          paidAmount: paymentMethod === "cash" ? paid : totals.total,
          customerName: customerName || undefined,
        },
      },
      {
        onSuccess: (data) => {
          toast({ title: "Transaction created successfully" });
          setLocation(`/checkout/confirm/${data.id}`);
        },
        onError: () => {
          toast({ title: "Failed to create transaction", variant: "destructive" });
        },
      }
    );
  };

  return (
    <div className="flex flex-col md:flex-row h-full">
      {/* Product Selection */}
      <div className="flex-1 p-6 flex flex-col overflow-hidden border-r">
        <div className="mb-6 relative">
          <Search className="absolute left-3 top-3 h-5 w-5 text-muted-foreground" />
          <Input
            className="pl-10 h-12 text-lg"
            placeholder="Search by product name, SKU, or scan barcode..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        
        <div className="flex-1 overflow-y-auto">
          {loadingProducts ? (
            <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-4">
              {[1, 2, 3, 4, 5, 6].map((i) => <Skeleton key={i} className="h-32 rounded-xl" />)}
            </div>
          ) : products?.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              No products found.
            </div>
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-4 pb-20">
              {products?.map((product) => (
                <Card 
                  key={product.id} 
                  className={`cursor-pointer transition-colors hover:border-primary ${product.stockQty <= 0 ? 'opacity-50' : ''}`}
                  onClick={() => handleAddToCart(product)}
                >
                  <CardContent className="p-4 flex flex-col h-full justify-between">
                    <div>
                      <p className="font-medium text-sm line-clamp-2">{product.name}</p>
                      <p className="text-xs text-muted-foreground mt-1">{product.category}</p>
                    </div>
                    <div className="mt-4 flex items-end justify-between">
                      <p className="font-bold text-lg text-primary">${product.price.toFixed(2)}</p>
                      <p className={`text-xs ${product.stockQty <= product.lowStockThreshold ? 'text-destructive font-bold' : 'text-muted-foreground'}`}>
                        {product.stockQty} in stock
                      </p>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Cart & Payment */}
      <div className="w-full md:w-96 lg:w-[400px] flex flex-col bg-slate-50 dark:bg-slate-900/50">
        <div className="p-4 border-b">
          <h2 className="text-xl font-bold">Current Order</h2>
        </div>
        
        {/* Cart Items */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {cart.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-muted-foreground">
              <ShoppingCart className="h-12 w-12 mb-4 opacity-20" />
              <p>Cart is empty</p>
            </div>
          ) : (
            cart.map((item) => (
              <div key={item.product.id} className="flex flex-col bg-background p-3 rounded-lg border shadow-sm">
                <div className="flex justify-between items-start mb-2">
                  <p className="font-medium text-sm pr-4 line-clamp-1">{item.product.name}</p>
                  <Button variant="ghost" size="icon" className="h-6 w-6 text-muted-foreground hover:text-destructive shrink-0" onClick={() => handleRemoveFromCart(item.product.id)}>
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Button variant="outline" size="icon" className="h-7 w-7" onClick={() => handleUpdateQuantity(item.product.id, -1)}>
                      <Minus className="h-3 w-3" />
                    </Button>
                    <span className="w-6 text-center font-medium text-sm">{item.quantity}</span>
                    <Button variant="outline" size="icon" className="h-7 w-7" onClick={() => handleUpdateQuantity(item.product.id, 1)}>
                      <Plus className="h-3 w-3" />
                    </Button>
                  </div>
                  <p className="font-bold text-sm">
                    ${(item.product.price * item.quantity).toFixed(2)}
                  </p>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Payment Summary */}
        <div className="p-4 bg-background border-t shadow-[0_-4px_10px_-5px_rgba(0,0,0,0.1)] z-10">
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <User className="h-4 w-4 text-muted-foreground" />
              <Input 
                placeholder="Customer Name (Optional)" 
                value={customerName}
                onChange={(e) => setCustomerName(e.target.value)}
                className="h-9 text-sm"
              />
            </div>
            
            <div className="grid grid-cols-3 gap-2">
              <Button 
                variant={paymentMethod === "cash" ? "default" : "outline"} 
                className="h-10 text-xs flex flex-col py-1"
                onClick={() => setPaymentMethod("cash")}
              >
                <Banknote className="h-4 w-4 mb-1" /> Cash
              </Button>
              <Button 
                variant={paymentMethod === "card" ? "default" : "outline"} 
                className="h-10 text-xs flex flex-col py-1"
                onClick={() => setPaymentMethod("card")}
              >
                <CreditCard className="h-4 w-4 mb-1" /> Card
              </Button>
              <Button 
                variant={paymentMethod === "mobile_money" ? "default" : "outline"} 
                className="h-10 text-xs flex flex-col py-1"
                onClick={() => setPaymentMethod("mobile_money")}
              >
                <Smartphone className="h-4 w-4 mb-1" /> Mobile
              </Button>
            </div>

            <div className="flex justify-between items-center text-sm">
              <span className="text-muted-foreground">Subtotal</span>
              <span>${totals.subtotal.toFixed(2)}</span>
            </div>
            <div className="flex justify-between items-center text-2xl font-bold border-t pt-2">
              <span>Total</span>
              <span className="text-primary">${totals.total.toFixed(2)}</span>
            </div>

            {paymentMethod === "cash" && (
              <div className="space-y-2 pt-2 border-t">
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">Amount Paid</span>
                  <Input 
                    type="number" 
                    value={paidAmount}
                    onChange={(e) => setPaidAmount(e.target.value)}
                    className="w-32 text-right font-bold h-9"
                    placeholder="0.00"
                  />
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium text-muted-foreground">Change Due</span>
                  <span className={`text-lg font-bold ${changeDue > 0 ? 'text-green-600' : ''}`}>
                    ${changeDue.toFixed(2)}
                  </span>
                </div>
              </div>
            )}

            <Button 
              className="w-full h-12 text-lg font-bold mt-4" 
              size="lg"
              disabled={cart.length === 0 || createTransaction.isPending || (paymentMethod === "cash" && (parseFloat(paidAmount) || 0) < totals.total)}
              onClick={handleProcessPayment}
            >
              {createTransaction.isPending ? "Processing..." : `Charge $${totals.total.toFixed(2)}`}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
