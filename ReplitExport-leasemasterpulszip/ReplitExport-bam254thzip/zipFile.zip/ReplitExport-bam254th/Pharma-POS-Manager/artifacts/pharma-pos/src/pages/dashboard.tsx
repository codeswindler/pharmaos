import { useGetDashboardSummary, useGetRevenueTrend, useGetTopProducts, useGetLowStockAlerts, useGetRecentActivity } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { ArrowUpRight, ArrowDownRight, Package, AlertTriangle, TrendingUp, DollarSign, ShoppingCart, Users, Activity } from "lucide-react";
import { format } from "date-fns";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip as RechartsTooltip,
  ResponsiveContainer
} from "recharts";

function StatCard({ title, value, change, icon: Icon, formatAsCurrency = false }: any) {
  const isPositive = change > 0;
  const isNegative = change < 0;

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
        <Icon className="h-4 w-4 text-muted-foreground" />
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">
          {formatAsCurrency ? `$${value.toFixed(2)}` : value}
        </div>
        {change !== undefined && (
          <p className={`text-xs flex items-center mt-1 ${isPositive ? 'text-green-600' : isNegative ? 'text-red-600' : 'text-muted-foreground'}`}>
            {isPositive ? <ArrowUpRight className="h-3 w-3 mr-1" /> : isNegative ? <ArrowDownRight className="h-3 w-3 mr-1" /> : null}
            {Math.abs(change)}% from last period
          </p>
        )}
      </CardContent>
    </Card>
  );
}

export default function Dashboard() {
  const { data: summary, isLoading: loadingSummary } = useGetDashboardSummary();
  const { data: revenueTrend, isLoading: loadingTrend } = useGetRevenueTrend({ period: 'week' });
  const { data: topProducts, isLoading: loadingTop } = useGetTopProducts({ period: 'week' });
  const { data: lowStockAlerts, isLoading: loadingAlerts } = useGetLowStockAlerts();
  const { data: recentActivity, isLoading: loadingActivity } = useGetRecentActivity();

  if (loadingSummary) {
    return <div className="p-8 space-y-4"><Skeleton className="h-32 w-full" /><Skeleton className="h-64 w-full" /></div>;
  }

  return (
    <div className="p-8 space-y-6">
      <div>
        <h2 className="text-3xl font-bold tracking-tight text-primary">Dashboard</h2>
        <p className="text-muted-foreground">Welcome to PharmaPOS. Here's what's happening today.</p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <StatCard
          title="Today's Revenue"
          value={summary?.todayRevenue || 0}
          change={summary?.todayRevenueChange}
          icon={DollarSign}
          formatAsCurrency
        />
        <StatCard
          title="Transactions"
          value={summary?.todayTransactions || 0}
          change={summary?.todayTransactionsChange}
          icon={ShoppingCart}
        />
        <StatCard
          title="Avg Transaction"
          value={summary?.avgTransactionValue || 0}
          icon={TrendingUp}
          formatAsCurrency
        />
        <StatCard
          title="Low/Out of Stock"
          value={(summary?.lowStockCount || 0) + (summary?.outOfStockCount || 0)}
          icon={AlertTriangle}
        />
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
        <Card className="col-span-4">
          <CardHeader>
            <CardTitle>Revenue Trend (This Week)</CardTitle>
          </CardHeader>
          <CardContent className="pl-2 h-[300px]">
            {loadingTrend ? (
              <Skeleton className="h-full w-full" />
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={revenueTrend}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} />
                  <XAxis dataKey="label" fontSize={12} tickLine={false} axisLine={false} />
                  <YAxis fontSize={12} tickLine={false} axisLine={false} tickFormatter={(value) => `$${value}`} />
                  <RechartsTooltip formatter={(value: number) => [`$${value}`, "Revenue"]} />
                  <Bar dataKey="revenue" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>

        <Card className="col-span-3">
          <CardHeader>
            <CardTitle>Low Stock Alerts</CardTitle>
          </CardHeader>
          <CardContent>
            {loadingAlerts ? (
              <div className="space-y-2">
                <Skeleton className="h-10 w-full" />
                <Skeleton className="h-10 w-full" />
              </div>
            ) : lowStockAlerts?.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground flex flex-col items-center">
                <Package className="h-8 w-8 mb-2 opacity-50" />
                <p>All stock levels are optimal.</p>
              </div>
            ) : (
              <div className="space-y-4">
                {lowStockAlerts?.slice(0, 5).map((alert) => (
                  <div key={alert.productId} className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium leading-none">{alert.productName}</p>
                      <p className="text-xs text-muted-foreground">SKU: {alert.sku}</p>
                    </div>
                    <div className="text-right">
                      <p className={`text-sm font-bold ${alert.status === 'out' ? 'text-destructive' : 'text-amber-500'}`}>
                        {alert.stockQty} left
                      </p>
                      <p className="text-xs text-muted-foreground">Threshold: {alert.lowStockThreshold}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Top Selling Products</CardTitle>
          </CardHeader>
          <CardContent>
             {loadingTop ? (
              <div className="space-y-2">
                <Skeleton className="h-10 w-full" />
                <Skeleton className="h-10 w-full" />
              </div>
            ) : (
              <div className="space-y-4">
                {topProducts?.map((product) => (
                  <div key={product.productId} className="flex items-center justify-between border-b pb-2 last:border-0 last:pb-0">
                    <div>
                      <p className="text-sm font-medium">{product.productName}</p>
                      <p className="text-xs text-muted-foreground">{product.category}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium">{product.totalSold} sold</p>
                      <p className="text-xs font-bold text-primary">${product.totalRevenue.toFixed(2)}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Recent Activity</CardTitle>
          </CardHeader>
          <CardContent>
             {loadingActivity ? (
              <div className="space-y-2">
                <Skeleton className="h-10 w-full" />
                <Skeleton className="h-10 w-full" />
              </div>
            ) : (
              <div className="space-y-4">
                {recentActivity?.map((activity) => (
                  <div key={activity.id} className="flex items-start gap-3 border-b pb-3 last:border-0 last:pb-0">
                    <div className="mt-0.5 rounded-full p-1 bg-muted">
                      {activity.type === 'sale' && <DollarSign className="h-4 w-4 text-green-600" />}
                      {activity.type === 'stock_update' && <Package className="h-4 w-4 text-blue-600" />}
                      {activity.type === 'new_customer' && <Users className="h-4 w-4 text-primary" />}
                      {activity.type === 'low_stock' && <AlertTriangle className="h-4 w-4 text-destructive" />}
                      {activity.type === 'message_sent' && <Activity className="h-4 w-4 text-purple-600" />}
                    </div>
                    <div className="flex-1">
                      <p className="text-sm font-medium">{activity.description}</p>
                      <p className="text-xs text-muted-foreground">{format(new Date(activity.timestamp), 'MMM d, h:mm a')}</p>
                    </div>
                    {activity.amount && (
                      <div className="text-sm font-bold text-primary">
                        ${activity.amount.toFixed(2)}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
